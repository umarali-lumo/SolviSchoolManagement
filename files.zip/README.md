# Solvi School Basic

Offline-first school & academy management for small private schools and tuition academies in Pakistan.
Python 3.12 · PySide6 · SQLite · SQLAlchemy · ReportLab · openpyxl.

Students · Classes/Sections · Fee structures · Monthly invoices · Fee counter & receipts · WhatsApp reminders (English/Urdu) ·
Attendance · Dashboard · 17 reports (screen / CSV / Excel / PDF) · Branding · Safe backup & restore · Roles & audit log.

## Easiest start on Windows
Double-click **`run.bat`**. It finds Python 3.12+, creates a private environment, installs the packages (internet needed once), optionally loads demo data, and starts the program. Later runs just start it.

## Quick start (development, any OS)
```bash
python -m venv .venv && source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
python scripts/make_sample_db.py                          # optional demo data -> sample/school_sample.db
python run_solvi.py                                       # first launch asks for school name + admin password
pytest                                                    # 43 automated tests (set QT_QPA_PLATFORM=offscreen on headless machines)
```
To explore the demo school, copy `sample/school_sample.db` to `%LOCALAPPDATA%\SolviSchool\school.db`
(or run with `SOLVI_DATA_DIR=<folder containing a copy named school.db>`).
Demo logins: `admin/admin123`, `cashier/cashier123` (accountant), `teacher/teacher123`. **Never use these in a real school.**

## Windows installation (for the school)
1. Run `SolviSchoolBasic-Setup.exe` (or unzip the `SolviSchoolBasic` folder anywhere on drive C:) and start *Solvi School Basic*.
2. First start: enter the school name and create the administrator password.
3. School Settings → upload logo, set colours, invoice prefix, due day, backup folder.
4. Classes → create classes/sections. Fee Structures → enter fees per class. Students → add or import.

Data location: `%LOCALAPPDATA%\SolviSchool\school.db` (the program refuses to start if this is inside Google Drive/OneDrive/Dropbox).
Uninstalling does **not** delete school data.

## Building the Windows executable
On a Windows 10/11 PC with Python 3.12+: double-click `build_windows.bat`
(runs tests → builds sample DB → `pyinstaller SolviSchoolBasic.spec`). Output: `dist\SolviSchoolBasic\SolviSchoolBasic.exe`.
Optionally compile `installer\SolviSchoolBasic.iss` with Inno Setup to get a single `SolviSchoolBasic-Setup.exe`.

## Architecture
```
solvi_school/
  app_context.py      wires DB + services (the UI only talks to this)
  config/paths.py     %LOCALAPPDATA% handling, synced-folder guard
  database/           connection.py (FK on, BEGIN IMMEDIATE), models.py, migrations/ (PRAGMA user_version)
  services/           all business logic: student, class, fee, payment, ledger, attendance, reminder,
                      report, dashboard, backup, auth, settings, pdf
  ui/                 PySide6 pages (no business logic): dashboard, students/, classes/, fees/, payments/,
                      attendance/, reports/, settings/
  tests/              pytest suite (services + GUI smoke tests)
```
A future Pro edition can add services/tables/pages and append migrations without touching Basic code.

## Design decisions worth knowing
* **Money** is stored as integer whole PKR. No floats anywhere.
* **Transactions**: every service call is one SQLite transaction started with `BEGIN IMMEDIATE`; numbering uses counters inside that transaction.
* **Invoice numbers** `PREFIX-YYYY-000001`, receipts `PREFIX-YYYY-000001`; sequential per year, unique-constrained.
* **Duplicate invoices**: partial unique index on (student, month) where status ≠ Cancelled — cancelled invoices stay and can be regenerated.
* **Previous balance** is *rolled forward*: when a new invoice is issued, the open balance of older invoices is moved onto it
  (`forwarded_amount`), so money is never counted twice. Cancelling the new invoice restores the old balances.
  Spec example: 5,000 + 1,000 − 500 + 2,000 = 7,500; pay 5,000 → 2,500 outstanding (tested).
* **Payments** allocate oldest-first across selected invoices; excess is rejected unless “advance payment” is ticked, in which case it
  becomes credit applied automatically to the next invoice. A per-form token makes a repeated click harmless.
* **Reversal** never deletes: payment is marked *Reversed* with who/when/why, invoice balances are recomputed, audit row written (admin only).
* **Backups** use SQLite’s online backup API → temp file → integrity check → rename. Auto-backup once a day while the app is open, retention
  configurable. Restore verifies the file, makes a safety copy first, then replaces the data. Logo and student photos are stored *inside* the database so a backup is complete.
* **Migrations**: ordered functions in `database/migrations/__init__.py` keyed by `PRAGMA user_version`; a backup is taken before any pending migration on an existing database.

## Known limitations
* PDFs use the built-in Helvetica font: Latin-script names print correctly; Urdu-script text in PDFs would need a bundled TTF font (reminder messages on screen/WhatsApp are fine).
* Single computer / single user at a time. Do not point two PCs at one database file.
* "Print" opens the generated PDF in the system PDF viewer (on Windows it sends it to the default printer via the shell *print* verb).
