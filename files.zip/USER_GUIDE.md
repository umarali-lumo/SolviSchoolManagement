# Solvi School Basic – User Guide for School Staff

## 1. Signing in
Enter your username and password. The first time the program runs, the owner/administrator creates the school and a password.
There are three kinds of users:
* **Administrator** – everything, including fee structures, cancelling invoices, reversing payments, settings, users, backups.
* **Accountant / cashier** – students, generating invoices, collecting fees, reminders, attendance, reports.
* **Teacher** – marking attendance, viewing students and reports.

## 2. First-time setup (do this once, in order)
1. **School Settings** → enter school name, address, phone; upload the logo; choose colours → *Save*.
2. **Classes** → *Add class* (Class 1, Class 2, Matric, Academy Batch A …). Select a class → *Add section* (A, B …).
3. **Fee Structures** → choose the class → type the fee amounts. Set “Charged” to **Monthly** for fees on every invoice (tuition) and
   **One-time / Annual** for admission fee, annual charges, etc. Set the due day and late fee → *Save*. Use *Copy to other classes* to save time.
4. **Students** → *+ Add student* (or *Import* from Excel/CSV: choose **Get template** first). Fill name, class, section, guardian and phone.
   Leave Admission no. blank to get one automatically.
5. **School Settings → Backup & restore** → choose a backup folder (a Google Drive folder is fine) and tick automatic backup.

## 3. Every month: invoices
**Fee Invoices → + Generate invoices** → pick the month → *All active students* → tick any one-time fees to include → *Generate*.
* A student never gets two invoices for the same month.
* Unpaid balances of earlier months are added to the new invoice as “Previous outstanding balance”.
* Individual extras/reductions (e.g. transport fee, sibling concession) go in the student’s profile → *Fee adjustments*; a fixed monthly discount is set when editing the student.
* *Apply late fees* adds the class late fee to invoices that are past due (once only).
* Select an invoice → **Print invoice** (opens the PDF) or **Save PDF**. *Save all shown as PDFs* prepares the whole list.
* Wrong invoice? Administrator selects it → **Cancel invoice** with a reason. It stays on record and can be regenerated.

## 4. Collecting fees (the fee counter)
1. **Fee Collection** → type part of the student’s name, admission number or parent’s phone → click the student.
2. Their open invoices appear. Keep the invoice(s) selected (oldest are paid first). The amount fills in automatically; change it for a part-payment.
3. Choose Cash / Bank transfer / Cheque / Other. For cheque or bank transfer, type the cheque number or transaction ID.
4. **Record payment and print receipt**. The receipt PDF opens immediately. Pressing the button twice cannot record the money twice.
5. If a parent pays more than is owed, tick *Record any excess as an advance payment*; it is used on the next invoice automatically.
* **Receipts & payment history** tab: search, **reprint** any receipt, or (administrator) **Reverse payment** with a reason (e.g. cheque bounced). Reversed receipts are never deleted – they are marked REVERSED.

## 5. Fee reminders
**Fee Reminders** lists students who are due soon, due today, overdue or part-paid, with the amount owed.
Select a student → the message preview appears (choose **English** or **اردو**). Then:
* **Copy message**, or **Open WhatsApp** (opens WhatsApp with the message ready – *you* press Send), then **Mark as sent**.
* **Step through all…** walks through every listed parent one at a time. Nothing is ever sent automatically.
The *Reminder history* tab shows what was sent and when. Reminder days are set in School Settings → Billing.

## 6. Attendance
**Attendance** → choose class (and section) and date → everyone starts unmarked. Click **Mark all present**, then change the absentees/leaves → **Save attendance**.
Opening a day that is already saved shows the saved marks; saving changes asks for confirmation. *Daily view* and *Monthly view* tabs show totals and percentages
(percentage = days present ÷ days marked).

## 7. Reports
**Reports** → pick a report → set the class/date/month → *Show report*. Then **Export CSV**, **Export Excel**, **Save as PDF** or **Print**.
Available: student list, class lists, admissions, withdrawn; daily/monthly collection, paid, unpaid, part-paid, defaulters, student ledger, outstanding balances, class-wise collection;
daily/monthly attendance, attendance percentage, class summary.

## 8. New academic year
Classes → *Academic years* → add the new year → *Make current*. Use **Promote students…** on each class (starting with the highest class!) to move students up.
Student IDs never change. Then create the new year’s Fee Structures.

## 9. Backups – please read
* **Back up now** is in School Settings → Backup & restore. Check “Last successful backup” regularly.
* Choose a folder inside **Google Drive for Desktop** to get an off-site copy automatically. Never move the live database into Google Drive – the program will refuse to start if you do.
* **Restore** replaces all current data with a backup (after a safety copy). Only use it if data is lost or damaged, and ask an administrator.

## 10. Troubleshooting
| Problem | What to do |
|---|---|
| “Admission number already used” | Search for the student – they may already be enrolled. |
| Student missing from invoice run | Check they are *Active* and their class has a fee structure for the current academic year. |
| Forgot password | Another administrator can reset it in School Settings → Users. |
| Program won’t open after a crash | Start it again; if the message persists restore the newest backup from your backup folder. |
